# HandNavigate readiness audit

25 October 2026 | Checkout b9961fb | Windows review

## Verdict

HandNavigate is a functioning automation prototype with useful deterministic replay and practice workflows. It is not ready for your complete daily task: download 10 images from one real website and upload them to another without supervision. The upload action and end-to-end transfer pipeline are missing. The current daily scheduler runs the older owned-site image runner, not the new live-browser module.

No meaningful production-ready percentage can be measured from this repository. Passing tests measure their specific cases, not the probability that your two websites work. A promise of 100% bug-free operation on every internet site cannot be established by finite tests. A realistic release target is explicit supported sites, independently checked outcomes and safe, recoverable failures.

## Fresh verification performed

- Full local suite: 215 passed; 0 failures; 0 errors; 1 skipped; 216 collected tests.
- All Python application modules compiled successfully. Pytest collected 216 tests, including the live-browser cases omitted by the supplied release test command.
- Installed the project's exact runtime/dev requirements into an ignored local .venv and its matching Chromium build. The ordinary python command was not configured on this PC; the bundled Python runtime was used to create the environment.
- Actual HTTPS browser navigation to the public Playwright TodoMVC demo: OBSERVED, 4 controls, no AI calls.
- Actual supplied TodoMVC replay: 2 of 2 runs VERIFIED, with different input values; each executed 2 actions and passed 2 independent DOM checks; zero AI calls. Audit harness generated exact recipe/input receipts. These were fresh temporary contexts, not persistent authenticated accounts or recurring jobs.
- The fresh suite also passed the owned portal's browser sign-in, encrypted session capture, separate-context CSV export and expired-session rejection. This qualifies that controlled example on this machine, not either of your unspecified websites.
- The older environment's administrator-blocked browser result does not describe this Windows machine: the fresh public navigation and owned HTTP browser gate both passed here.
- No target-site credentials, live AI requests, uploads, destination publishing, overnight operation or real-person usability study were exercised.
- Historical reports describe 172 passed plus 2 skips for v0.4 and a separate 42-pass live suite. Those are previous evidence, not replacements for this Windows run.

Raw evidence is included beside this report. The public probe only establishes navigation; the public replay only establishes a basic two-step text workflow on that demo.

## What is usable now

| Capability | Assessment | Practical meaning |
|---|---|---|
| Practice Studio and guided form teaching | Implemented; test-covered | Useful for experimenting with recording, bindings, verification and bounded batches on the owned form. |
| Practice image collection | Implemented; test-covered | Collects fixture images with strict PNG checks; it is not a connector for arbitrary image sites. |
| Real website navigation | Fresh public-site smoke check passed | Live CLI accepts real URLs inside exact allowed origins. |
| Real website deterministic replay | Fresh public demo passed twice | Fill, click, select, check, key press, scroll, wait, navigate and click-triggered download are supported. |
| Teach any complex site by one demonstration | Partial prototype | Captures a supported action sequence; variables, loops, collection logic and business checks still need explicit authoring. |
| Download 10 images from your source site | Not established | Static steps could download from simple known controls, but there is no generic live image discovery/collection loop. |
| Upload images to another site | Missing | No upload action, set_input_files/file chooser execution or destination upload verifier. |
| Daily real-site download plus upload | Missing integration | Durable scheduling exists in the older practice lane; the live CLI is not connected to it. |
| Authenticated unattended operation | Experimental/incomplete | Live persistent profiles and an older encrypted vault exist in separate lanes; the unattended lifecycle is not integrated. |
| Natural language agent | Implemented but unqualified live | Groq transport is present; each action asks the operator. A real model request was not tested. |
| Access every website | Unsupported promise | Main-frame controls only; popups/dialogs stop runs, WebSockets/service workers are blocked, and allowed dependencies/methods need explicit scope. |

## Main findings and source evidence

1. BLOCKER: no file upload primitive. handnavigate/live/contracts.py:17 lists every accepted operation; upload is absent. handnavigate/live/browser.py:235 executes the closed operation set. This alone blocks the requested source-to-destination workflow. Playwright itself already supports file inputs and file chooser uploads; HandNavigate must add a reviewed, restricted wrapper.

2. BLOCKER: scheduling and live automation are disconnected. handnavigate/controller.py:40 invokes the older Runner. handnavigate/runner.py:156 rejects origins other than explicit http://127.0.0.1:PORT. This is an intentional practice boundary, not a one-line production fix. Removing that restriction would not implement collection, authentication or uploads.

3. HIGH: the default test/CI path misses the new live core. run_tests.py imports only test_lab and test_v02/v03/v04. .github/workflows/qualification.yml:30 invokes that script and installs runtime requirements rather than the development set. A future live-browser regression can escape that gate. Our explicit pytest tests command includes all cases.

4. HIGH: live download verification is not image/task verification. handnavigate/live/browser.py:243-258 saves random .bin filenames and enforces a post-transfer 25 MiB limit. Lines 278-301 verify file existence/hash and selected count/hash checks. They do not decode images, enforce JPEG/PNG/WebP, establish original-versus-thumbnail quality or confirm the chosen source items. The old verify_png at handnavigate/runner.py:67 intentionally accepts only a minimal synthetic PNG profile, unsuitable for general photos.

5. HIGH: no live transfer journal or destination reconciliation. handnavigate/live/workflows.py:94-116 runs a flat sequence, halts on exceptions and writes a result. It has no per-image upload receipt, target deduplication or safe resume after an uncertain remote write. The older fixture journal does not provide those live guarantees.

6. HIGH: modern-site and login compatibility is bounded. handnavigate/live/browser.py:68-98 closes extra pages/dialogs and blocks WebSockets; open_driver at line 309 blocks service workers. The recorder and locators operate in the main frame. Many real tasks require an adapter for additional login/CDN/API origins, permitted write requests and richer surfaces. Broadly allowing POST is not sufficient to establish the correct upload effect.

7. HIGH: personal credentials and data need an operational lifecycle. The CLI can retain dedicated persistent browser profiles, but those are not wired to the earlier encrypted vault or an unattended OS secret store. Heuristic screenshot/control masking cannot guarantee private page text is removed. Review actual-site account identity, retention and Windows file access before recurring real-account work.

8. MEDIUM: the live runtime needs hard operational bounds. browser.py checks a 900-second budget between actions and limits individual operations, but has no independent process watchdog; download size is checked after transfer. Real daily operation needs safe cancellation, resource limits, bounded retry and handling of machine restart/sleep.

9. MEDIUM: product usability is still practice-oriented. Studio has no integrated real-site source/destination transfer setup. Basic live work involves CLI commands, JSON recipes and exact-input approvals. That is usable by a developer experimenting with simple sites, but does not meet an everyday self-service product expectation.

## Pending work in priority order

The accompanying HANDNAVIGATE_BACKLOG.csv contains these requirements with acceptance tests. P0 blocks your first reliable daily workflow; P1 hardens and generalizes it; P2 covers distribution and maintenance.

### P0-01: Define the first source and destination

Document both URLs, account identity, album/folder, image selection and duplicate rules, daily time and timezone.

Acceptance: A written acceptance example identifies exactly which 10 images should appear where.

### P0-02: Implement genuine file uploads

Add a typed upload action using file inputs/file chooser; allow only manifest-approved local files; review submit/publish actions.

Acceptance: 10 validated images reach the target; missing, substituted and outside-folder files are rejected.

### P0-03: Add a source collection adapter

Discover stable image identities and original download URLs, paginate or scroll, skip ineligible items and stop at a bounded count.

Acceptance: Exactly 10 eligible images, or an explicit partial result when fewer exist; no infinite loop.

### P0-04: Build the artifact manifest

Keep source identity/URL, hash, MIME, extension, dimensions, size and target identity. Validate real JPEG/PNG/WebP decoding and content.

Acceptance: HTML login responses, corrupted files, thumbnails where originals are required and duplicates do not pass.

### P0-05: Verify destination outcomes

Read back uploaded assets from the destination or its API, checking stable IDs, account/folder and processing state.

Acceptance: A success banner alone cannot mark a transfer complete; all 10 target assets are independently confirmed.

### P0-06: Journal and reconcile transfers

Persist SELECTED -> DOWNLOADED -> VALIDATED -> UPLOADING -> CONFIRMED per item. Use idempotency keys when supported; inspect uncertain remote outcomes before retry.

Acceptance: Kill after server acceptance and before local confirmation; restart without silently duplicating uploads.

### P0-07: Qualify login for both actual sites

Provide dedicated site profiles, expected-account checks, expiry detection and manual MFA/CAPTCHA recovery; use Windows-backed secret protection for unattended access.

Acceptance: Wrong-account and expired-login cases halt before upload; a fresh browser restores the intended session.

### P0-08: Integrate live transfers with daily scheduling

Connect the live pipeline to durable scheduling, occurrence deduplication, cancellation and restart recovery; configure startup and sleep/wake policy.

Acceptance: An actual Asia/Kolkata daily run survives restart, skips or reconciles missed runs and never overlaps itself.

### P0-09: Repair the test entry point and CI

Install requirements-dev.txt, include tests/live, and trigger on live code, dev dependency and workflow changes; preserve strict browser HTTP gating.

Acceptance: One documented command runs the complete 216-test baseline plus new transfer tests on Windows.

### P1-10: Add bounded recovery and hard limits

Retry only safe reads/transfers with backoff; handle 429/5xx; cap streamed bytes, total run time and disk use; terminate stalled workers.

Acceptance: Network loss, oversized/stalled transfer and disk-full tests finish within budgets without false success.

### P1-11: Connect the real workflow to the UI

Expose source, target, 10-image rule, account/folder, rehearsal, schedule, progress, pause and failure recovery in Studio.

Acceptance: A person completes setup and repairs a failed run without editing JSON or Python.

### P1-12: Generalize through explicit adapter interfaces

Define source.list_items/download and target.upload/find_uploaded/verify, with API adapters where available and browser adapters otherwise.

Acceptance: A second source and second destination can be added without rewriting scheduling, the journal or verifiers.

### P1-13: Support richer site interactions incrementally

Add scoped iframe/tab handling, custom widgets and reviewed login/CDN/API dependencies where a supported site needs them.

Acceptance: Each supported site passes its own fixtures and live acceptance suite; unsupported controls stop clearly.

### P1-14: Validate privacy and action boundaries

Review page-text/screenshot retention, local Windows ACLs, profile exports, prompt-injection resistance and destination/method permissions.

Acceptance: Secrets are absent from export artifacts and tests cannot upload an unrelated local file or act on an unapproved destination.

### P1-15: Measure real reliability

Run supervised end-to-end trials, injected failures and a multi-day daily schedule with measured outcomes and interventions.

Acceptance: Proposed release gate: 100 repeated complete trials plus 30 actual daily runs, zero silent wrong/duplicate uploads; report partials and interventions separately.

### P2-16: Package and maintain

Provide a reproducible Windows launcher/installer, dependency review, startup instructions, logs, notifications, retention and update/rollback handling.

Acceptance: A clean Windows machine can install, rehearse, schedule, pause, update and recover using documented steps.

## A reusable design for many sites

Use one common pipeline: source adapter -> bounded discovery of 10 eligible items -> download -> image validation and manifest -> destination adapter -> upload -> independent destination confirmation -> durable journal -> daily scheduler.

Keep scheduling, files, deduplication, verification and recovery generic. Put site-specific selectors, account checks, original-image extraction, pagination and upload semantics in small versioned adapters. Prefer supported APIs for a source or target that offers them; use browser adapters otherwise. AI can help author a draft or propose repairs, followed by explicit review and independent verification. The repeatable execution path should not require a model to guess every click.

For a new site, inventory exact origins and dependencies, demonstrate the real task, bind parameters, add item/target identity checks, rehearse, then qualify that adapter. Record supported and unsupported features explicitly. MFA, CAPTCHA or anti-automation challenges require a clear human-intervention state rather than an assumption of universal access.

Start with the user's two actual sites. Generalizing before the complete transfer succeeds on them would conceal the largest current gaps. Those URLs, account details and selection rules were not supplied in this review, so compatibility with them remains untested.

## Suggested release acceptance tests

- Happy path: exactly 10 valid source images appear in the correct destination account/folder with independent target confirmation.
- Selection: pagination, lazy loading, fewer than 10 items, previously transferred images, duplicate content and expiring signed download links.
- Data validity: JPEG/PNG/WebP, corrupted/truncated files, login HTML pretending to be an image, wrong dimensions and missing originals.
- Remote writes: one upload fails, delayed server-side processing, success banner with missing asset, wrong destination folder and duplicate submission.
- Recovery: stop before upload, stop after server acceptance, crash before saving the receipt, rerun the same daily occurrence and restart after sleep/offline time.
- Accounts: wrong account, expired source login, expired destination login and manual MFA recovery.
- Site drift: renamed/moved controls, ambiguous targets, new iframe/tab and changed permissions; halt with useful evidence.
- Operations: 429/5xx/network timeout, stalled/oversized download, disk full, browser crash and hard process timeout.
- Product: a real person sets up the two-site job and recovers a failure without developer edits.
- Daily operation: observe actual scheduled runs over multiple days; simulated clocks are not overnight reliability evidence.

These are proposed gates, not tests of the missing transfer functionality that have already passed. Track verified full jobs, partial jobs, incorrect outcomes, duplicates and interventions separately. A safe halt is useful behavior but is not a completed transfer.

## How to repeat the checks

From the repository root in PowerShell:

    .\.venv\Scripts\python.exe -m pytest tests -q --junitxml=analysis/test-results-2026-10-25.xml
    .\.venv\Scripts\python.exe -m compileall -q handnavigate
    .\.venv\Scripts\python.exe -m handnavigate live doctor --url https://demo.playwright.dev/todomvc/ --authorized-site --out analysis/public-browser-probe
    .\.venv\Scripts\python.exe analysis/public_replay_check.py
    .\.venv\Scripts\python.exe analysis/build_report.py

The final two commands are audit helpers, not changes to application behavior. No production source, requirements or existing historical evidence were changed. There is no commit or push from this audit.

## References

- Repository evidence: README.md, LIVE_BROWSER_START_HERE.md, research/BUILD_BACKLOG.md, research/LIVE_CORE_TEST_REPORT.md, research/TEST_REPORT.md, DELIVERY_STATUS.json and the source files cited above.
- Official Playwright upload documentation: https://playwright.dev/python/docs/input#upload-files
- Official Playwright file chooser API: https://playwright.dev/python/docs/api/class-filechooser
- Official Playwright authentication documentation: https://playwright.dev/python/docs/auth

Scope: code inspection, complete local automated suite, a public navigation smoke check and two public demo replays on 25 October 2026. This is not a penetration test, target-site qualification, live-AI evaluation or multi-day production certification.

## Fresh skipped cases

- tests.test_lab.BrowserTests.test_16_redirect_blocked: HTTP redirect integration cannot be represented by an offline Blob fixture; policy unit-tested separately
